//package com.EazyPay.demo;
//
//import static org.assertj.core.api.Assertions.assertThat;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import org.slf4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.annotation.Rollback;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.WalletPay.demo.Service.WalletPayServiceImpl;
//import com.WalletPay.demo.entity.Transaction_Details;
//import com.WalletPay.demo.entity.Wallet;
//@Transactional
//@SpringBootTest
//class EazyPayApplicationTests {
////
////	@Test
////	void contextLoads() {
////	}
//	private static Logger logger;
//	
//	@Autowired
//	private WalletPayServiceImpl wpsi;
//	
//	@BeforeAll
//	static void setUpbBeforeClass() {
//		logger.info("SetUpClass Called..");
//		
//	}
//	@BeforeEach
//	void setup() {
//		logger.info("Test cases Started");
//		List<Transaction_Details> ls=	new ArrayList<Transaction_Details>(); 
//		wpsi.addUser(new Wallet("8855996644","m@gmail.com","556633221144","Mahesh",0.0f,"1111",ls));
//		System.out.println("Test Case Started");
//	}
//	@AfterEach
//	void tearDown() {
//		logger.info("Test cases over");
//		System.out.println("test cases over");
//	}
//	
//	@Test
//	@DisplayName("User Creation Successfull")
//	@Rollback(true)
//	public void createFirstTest() throws Exception{
//		logger.info("Test Case - User Regestration successfull");
//		List<Transaction_Details> ls=	new ArrayList<Transaction_Details>();
//		Wallet message=wpsi.addUser(new Wallet("8888888888","m@gmail.com","556633221144","Yash",0.0f,"1111",ls));
//		String expectedMessage="Yash is regestered ";
//		assertEquals(message,expectedMessage);
//	}
//	
//	@Test
//	@DisplayName("User Creation failed")
//	@Rollback(true)
//	public void createSecodTest() throws Exception{
//	logger.info("Test Case - User Regestration failed..User ");
//	List<Transaction_Details> ls=	new ArrayList<Transaction_Details>();
//	Wallet message=wpsi.addUser(new Wallet("8855996644","m@gmail.com","556633221144","Mahesh",0.0f,"1111",ls));
//	String expectedMessage="Mahesh is already regestered...Try different user ";
//	assertEquals(message,expectedMessage);
//	}
//	
//	@Test
//	@DisplayName("Get user with mobile")
//	@Rollback(true)
//	public void getUserFirstTest() throws Exception{
//		logger.info("Test case...Get User with mobile successfull");
//		List<Transaction_Details> ls=	new ArrayList<Transaction_Details>();
//		Wallet user=new Wallet("8855996644","m@gmail.com","556633221144","Mahesh",0.0f,"1111",ls);
//		Wallet existinguser=wpsi.getUser("556633221144");
//		assertThat(user).isEqualToComparingFieldByField(existinguser);
//	} 
//	
////	@Test
////	@DisplayName("Get user with mobile-user doesnt exist..")
////	@Rollback(true)
////	public void getUserSecondTest() throws Exception{
////		logger.info("Test case...Get User with mobile failed");
////		String message =null;
////		
////			
////		
////			
////		
////		String expectedMessage="User doesnt exist..Enter correct mobile number..";
////		assertEquals(message, expectedMessage);
////	} 
//
//	@Test
//	@DisplayName("Add money into wallet")
//	@Rollback(true)
//	public void addmoneytoWalletTest()throws Exception{
//		logger.info("Test case-Add money to wallet");
//		String message=wpsi.addBalanceToWallet("7758990640", 100);
//		String expectedMessage=100.0+"is added into wallet";
//		assertEquals(message, expectedMessage);
//	}
//	
//	
//	@Test
//	@DisplayName("Add money into Bank account")
//	@Rollback(true)
//	public void addmoneytoBankTest()throws Exception{
//		logger.info("Test case-Add money to Bank");
//		String message=wpsi.addBalanceToBank("7758990640", 100);
//		String expectedMessage=100.0+"is added into Bank";
//		assertEquals(message, expectedMessage);
//	}
//	
//	
//	@Test
//	@DisplayName("Trasfer Amount successfull")
//	@Rollback(true)
//	public void transferFirstTest()throws Exception{
//		logger.info("Test case-Successfull money transfer");
//		String message=wpsi.transferFund("7758990640","8855223366",100,"Recharge");
//		String expectedMessage="Status ok";
//		assertEquals(message, expectedMessage);
//	}
//	
//	@Test
//	@DisplayName("Trasfer Amount failed")
//	@Rollback(true)
//	public void transferSecondTest()throws Exception{
//		logger.info("Test case-failed money transfer");
//		String message=wpsi.transferFund("7758990640","8855223366",100,"Recharge");
//		String expectedMessage="Receiver doesn't exist..Enter correct receiver number";
//		assertEquals(message, expectedMessage);
//	}
//	
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
